# CPSC-481-Project-1
Formulate undergraduate advising for the Bachelor of Science in Computer Science as a state-space search problem and use the A* search algorithm to implement a planning tool.

Make sure that under 'download_data.py' you change the variable xl = pd.ExcelFile('./data.xlsx') from ./data.xlsx to the relative path of the data.xlsx

Libraries to install

pip install pd

pip install pandas

To run the program, run it from main.py
