# CPSC-481-Project-1
Formulate undergraduate advising for the Bachelor of Science in Computer Science as a state-space search problem and use the A* search algorithm to implement a planning tool.

Libraries to install

pip install pd

pip install pandas